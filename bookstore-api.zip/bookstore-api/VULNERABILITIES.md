# Planted Vulnerabilities — Ground Truth

Use this as the answer key when evaluating Vidura's SAST output.

| # | File | CWE | Vulnerability | Severity |
|---|------|-----|---------------|----------|
| 1 | `app/core/config.py` | CWE-798 | Hardcoded JWT secret (`SECRET_KEY`) | High |
| 2 | `app/core/config.py` | CWE-798 | Hardcoded DB password (`DB_ADMIN_PASSWORD`) | High |
| 3 | `app/core/config.py` | CWE-798 | Hardcoded SMTP password | High |
| 4 | `app/core/config.py` | CWE-798 | Hardcoded payment API key | High |
| 5 | `app/core/config.py` | CWE-521 | Weak admin password `admin123` | Medium |
| 6 | `app/core/config.py` | CWE-798 | Hardcoded support phone number | Low |
| 7 | `app/core/config.py` | CWE-489 | `DEBUG=True` left active | Low |
| 8 | `app/utils/security.py` | CWE-327 | MD5 used for password hashing (no salt) | High |
| 9 | `app/utils/security.py` | CWE-330 | `random.randint` used for OTP (not cryptographically secure) | Medium |
| 10 | `app/utils/security.py` | CWE-532 | OTP written to application log | Medium |
| 11 | `app/core/dependencies.py` | CWE-532 | Full JWT payload written to debug log | Low |
| 12 | `app/api/auth/router.py` | CWE-89 | SQL Injection in `/auth/login` — username f-string into query | Critical |
| 13 | `app/api/auth/router.py` | CWE-532 | PII (email, phone) written to log on register | Medium |
| 14 | `app/api/auth/router.py` | CWE-200 | OTP returned in API response body | High |
| 15 | `app/api/auth/router.py` | CWE-521 | No password strength check on `/auth/me/password` | Medium |
| 16 | `app/api/books/router.py` | CWE-89 | SQL Injection in `/books/search` — `q` f-string into query | Critical |
| 17 | `app/api/orders/router.py` | CWE-639 | IDOR in `GET /orders/{order_id}` — no ownership check | High |
| 18 | `app/api/reviews/router.py` | CWE-89 | SQL Injection in `GET /reviews/book/{book_id}` — f-string query | Critical |
| 19 | `app/api/reviews/router.py` | CWE-79 | Stored XSS risk — `comment` stored and returned unescaped | Medium |
| 20 | `app/api/reviews/router.py` | CWE-639 | IDOR in `DELETE /reviews/{review_id}` — no ownership check | High |
| 21 | `app/api/admin/router.py` | CWE-862 | Entire admin router has no authentication guard | Critical |
| 22 | `app/api/admin/router.py` | CWE-200 | `GET /admin/users` returns password hashes and PII | High |
| 23 | `app/api/admin/router.py` | CWE-200 | `GET /admin/config` returns JWT secret and admin password | Critical |
| 24 | `app/api/admin/router.py` | CWE-78 | OS Command Injection in `POST /admin/ping` | Critical |
| 25 | `app/api/admin/router.py` | CWE-94 | Code Injection via `eval()` in `POST /admin/calculate` | Critical |
| 26 | `app/api/admin/router.py` | CWE-22 | Path Traversal in `GET /admin/file/download` | High |
| 27 | `app/api/admin/router.py` | CWE-502 | Insecure Deserialization — `pickle.loads` on user input | Critical |
| 28 | `app/api/admin/router.py` | CWE-918 | SSRF in `GET /admin/fetch` — unvalidated URL | High |
| 29 | `app/api/admin/router.py` | CWE-22 | Path Traversal in `GET /admin/logs` | Medium |
| 30 | `app/api/admin/router.py` | CWE-862 | `DELETE /admin/users/{id}` — no auth, any caller can delete users | Critical |
| 31 | `app/main.py` | CWE-942 | Permissive CORS — `allow_origins=["*"]` with `allow_credentials=True` | Medium |
| 32 | `run.py` | CWE-489 | `reload=True`, binding `0.0.0.0` — debug config in production launcher | Low |
| 33 | `.env.example` | CWE-798 | Secrets committed to version control in `.env.example` | High |
| 34 | `app/models/schemas.py` | CWE-20 | `email` field is plain `str`, no format validation | Low |

**Total:** 34 planted issues across 9 files
- Critical: 8 | High: 11 | Medium: 9 | Low: 6

**Clean file for false-positive check:** `app/api/books/router.py`
(except the `search` endpoint) — all other CRUD uses parameterized queries.
