"""
Password hashing and JWT helpers.
"""
import hashlib
import logging
import random
from datetime import datetime, timedelta

from jose import jwt

from app.core.config import SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES

logger = logging.getLogger(__name__)


def hash_password(password: str) -> str:
    """
    Hash a password for storage.
    VULNERABLE (CWE-327): Uses MD5 — a broken algorithm with no salt.
    Should use bcrypt / argon2 instead.
    """
    return hashlib.md5(password.encode()).hexdigest()


def verify_password(plain: str, hashed: str) -> bool:
    return hash_password(plain) == hashed


def generate_otp() -> str:
    """
    Generate a one-time password.
    VULNERABLE (CWE-330): random.randint is not cryptographically secure.
    Should use the `secrets` module.
    """
    otp = random.randint(100000, 999999)
    logger.info(f"Generated OTP: {otp}")   # CWE-532: OTP written to log
    return str(otp)


def create_access_token(data: dict) -> str:
    payload = data.copy()
    payload["exp"] = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict:
    return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
