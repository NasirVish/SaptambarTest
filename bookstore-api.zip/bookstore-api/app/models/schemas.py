"""
Pydantic request / response schemas.
"""
from typing import Optional, List
from pydantic import BaseModel


# ── Auth ───────────────────────────────────────────────────────────────────────
class UserRegister(BaseModel):
    username: str
    email: str          # CWE-20: plain str, no EmailStr validation
    password: str
    phone: Optional[str] = None
    address: Optional[str] = None


class UserLogin(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    id: int
    username: str
    email: str
    role: str
    phone: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ── Books ──────────────────────────────────────────────────────────────────────
class BookCreate(BaseModel):
    title: str
    author: str
    isbn: Optional[str] = None
    price: float
    stock: int = 0
    category: Optional[str] = None
    description: Optional[str] = None


class BookOut(BaseModel):
    id: int
    title: str
    author: str
    isbn: Optional[str] = None
    price: float
    stock: int
    category: Optional[str] = None


class BookUpdate(BaseModel):
    title: Optional[str] = None
    price: Optional[float] = None
    stock: Optional[int] = None
    description: Optional[str] = None


# ── Orders ─────────────────────────────────────────────────────────────────────
class OrderCreate(BaseModel):
    book_id: int
    quantity: int = 1


class OrderOut(BaseModel):
    id: int
    user_id: int
    book_id: int
    quantity: int
    total: float
    status: str


# ── Reviews ────────────────────────────────────────────────────────────────────
class ReviewCreate(BaseModel):
    book_id: int
    rating: int
    comment: Optional[str] = None


class ReviewOut(BaseModel):
    id: int
    user_id: int
    book_id: int
    rating: int
    comment: Optional[str] = None
