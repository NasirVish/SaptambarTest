"""
Book catalog endpoints: list, search, get, create, update, delete.
"""
import logging
from typing import Optional, List

from fastapi import APIRouter, HTTPException, Query, Depends

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin
from app.models.schemas import BookCreate, BookOut, BookUpdate

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/books", tags=["Books"])


@router.get("/", response_model=List[BookOut])
def list_books(
    category: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
):
    """
    Return a paginated list of books, optionally filtered by category.
    Clean implementation — parameterized query, safe pagination.
    """
    db = get_db()
    offset = (page - 1) * page_size
    if category:
        rows = db.execute(
            "SELECT * FROM books WHERE category=? LIMIT ? OFFSET ?",
            (category, page_size, offset),
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM books LIMIT ? OFFSET ?", (page_size, offset)
        ).fetchall()
    db.close()
    return [dict(r) for r in rows]


@router.get("/search", response_model=List[BookOut])
def search_books(q: str = Query(..., description="Search by title or author")):
    """
    Search books by title or author.
    VULNERABLE (CWE-89): search term is concatenated directly into SQL.
    e.g. q=' OR '1'='1  dumps the entire table.
    """
    db = get_db()
    query = f"SELECT * FROM books WHERE title LIKE '%{q}%' OR author LIKE '%{q}%'"
    rows = db.execute(query).fetchall()
    db.close()
    return [dict(r) for r in rows]


@router.get("/{book_id}", response_model=BookOut)
def get_book(book_id: int):
    """Return a single book by ID."""
    db = get_db()
    row = db.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    db.close()
    if not row:
        raise HTTPException(status_code=404, detail="Book not found")
    return dict(row)


@router.post("/", response_model=BookOut, status_code=201)
def create_book(book: BookCreate, _: dict = Depends(require_admin)):
    """Create a new book (admin only)."""
    db = get_db()
    cur = db.execute(
        "INSERT INTO books (title,author,isbn,price,stock,category,description) VALUES (?,?,?,?,?,?,?)",
        (book.title, book.author, book.isbn, book.price, book.stock, book.category, book.description),
    )
    db.commit()
    row = db.execute("SELECT * FROM books WHERE id=?", (cur.lastrowid,)).fetchone()
    db.close()
    return dict(row)


@router.put("/{book_id}", response_model=BookOut)
def update_book(book_id: int, updates: BookUpdate, _: dict = Depends(require_admin)):
    """Update a book's details (admin only)."""
    db = get_db()
    row = db.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    if not row:
        db.close()
        raise HTTPException(status_code=404, detail="Book not found")

    merged = {**dict(row), **{k: v for k, v in updates.model_dump().items() if v is not None}}
    db.execute(
        "UPDATE books SET title=?,price=?,stock=?,description=? WHERE id=?",
        (merged["title"], merged["price"], merged["stock"], merged["description"], book_id),
    )
    db.commit()
    row = db.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    db.close()
    return dict(row)


@router.delete("/{book_id}", status_code=204)
def delete_book(book_id: int, _: dict = Depends(require_admin)):
    """Delete a book (admin only)."""
    db = get_db()
    db.execute("DELETE FROM books WHERE id=?", (book_id,))
    db.commit()
    db.close()
