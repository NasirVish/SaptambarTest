"""
Admin / diagnostic endpoints.
MULTIPLE VULNERABILITIES — see inline comments.
"""
import base64
import logging
import os
import pickle
import subprocess
from pathlib import Path

import requests
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse

from app.core.database import get_db
from app.core.config import ADMIN_PASSWORD, ADMIN_USERNAME, SECRET_KEY
from app.utils.logger import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/admin", tags=["Admin"])

UPLOAD_DIR = Path(__file__).resolve().parent.parent.parent.parent / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

# ── No auth guard on this entire router (CWE-862) ─────────────────────────────
# All endpoints below are admin-only by name but have no Depends(require_admin).


@router.get("/users")
def list_all_users():
    """
    List all users including passwords and PII.
    VULNERABLE (CWE-862): no authentication or authorisation check.
    VULNERABLE (CWE-200): returns password hashes and PII to any caller.
    """
    db = get_db()
    rows = db.execute("SELECT * FROM users").fetchall()
    db.close()
    return [dict(r) for r in rows]          # returns password column — CWE-200


@router.get("/config")
def expose_config():
    """
    VULNERABLE (CWE-200 + CWE-798): returns hardcoded secrets in response.
    No auth guard (CWE-862).
    """
    return {
        "admin_username":    ADMIN_USERNAME,
        "admin_password":    ADMIN_PASSWORD,   # CWE-200 + CWE-798
        "jwt_secret":        SECRET_KEY,        # CWE-200 + CWE-798
        "debug":             True,
    }


@router.post("/ping")
def ping_host(host: str):
    """
    Ping a host.
    VULNERABLE (CWE-78): host is interpolated into a shell command.
    e.g. host = "8.8.8.8; rm -rf /tmp/testfile"
    """
    result = subprocess.run(
        f"ping -c 2 {host}",    # CWE-78 — OS Command Injection
        shell=True, capture_output=True, text=True,
    )
    return {"stdout": result.stdout, "stderr": result.stderr}


@router.post("/calculate")
def calculate(expression: str):
    """
    Evaluate a math expression.
    VULNERABLE (CWE-94): bare eval() on user input allows arbitrary Python execution.
    e.g. expression = "__import__('os').system('id')"
    """
    result = eval(expression)   # CWE-94 — Code Injection
    return {"result": result}


@router.get("/file/download")
def download_file(filename: str):
    """
    Download a file from the uploads directory.
    VULNERABLE (CWE-22): filename is joined without sanitizing '../' sequences.
    e.g. filename = "../../app/core/config.py" leaks the config file.
    """
    path = UPLOAD_DIR / filename    # CWE-22 — Path Traversal
    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(path)


@router.post("/session/restore")
def restore_session(data: str):
    """
    Restore a serialised session object.
    VULNERABLE (CWE-502): untrusted base64 blob fed to pickle.loads —
    arbitrary code execution is possible.
    """
    raw = base64.b64decode(data)
    session = pickle.loads(raw)     # CWE-502 — Insecure Deserialization
    return {"restored": str(session)}


@router.get("/fetch")
def fetch_url(url: str):
    """
    Fetch a remote URL on the server's behalf.
    VULNERABLE (CWE-918 — SSRF): url is fully attacker-controlled.
    e.g. url = "http://169.254.169.254/latest/meta-data/" reaches cloud metadata.
    """
    resp = requests.get(url, timeout=5)    # CWE-918 — SSRF
    return {"status": resp.status_code, "body": resp.text[:500]}


@router.get("/logs")
def read_log_file(log_file: str = "app.log"):
    """
    Read a log file.
    VULNERABLE (CWE-22): log_file path not validated — can traverse outside logs/.
    VULNERABLE (CWE-200): log file contents (which include OTPs, emails) are
    returned to any unauthenticated caller.
    """
    log_dir = Path(__file__).resolve().parent.parent.parent.parent / "logs"
    path = log_dir / log_file          # CWE-22
    if not path.exists():
        raise HTTPException(status_code=404, detail="Log file not found")
    return {"content": path.read_text()}


@router.delete("/users/{user_id}")
def delete_user(user_id: int):
    """
    Delete a user account.
    VULNERABLE (CWE-862): no auth check — any caller can delete any user.
    """
    db = get_db()
    db.execute("DELETE FROM users WHERE id=?", (user_id,))
    db.commit()
    db.close()
    return {"message": f"User {user_id} deleted"}
