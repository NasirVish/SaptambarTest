"""
Authentication endpoints: register, login, OTP, profile.
"""
import logging

from fastapi import APIRouter, HTTPException, Depends

from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.core.config import SUPPORT_PHONE
from app.models.schemas import UserRegister, UserLogin, UserOut, TokenResponse
from app.utils.security import hash_password, verify_password, generate_otp, create_access_token

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=UserOut, status_code=201)
def register(user: UserRegister):
    """Register a new customer account."""
    db = get_db()
    # CWE-532: PII (email + phone) written to log
    logger.info(f"Register attempt: username={user.username} email={user.email} phone={user.phone}")

    try:
        db.execute(
            "INSERT INTO users (username,email,password,phone,address) VALUES (?,?,?,?,?)",
            (user.username, user.email, hash_password(user.password), user.phone, user.address),
        )
        db.commit()
        row = db.execute("SELECT * FROM users WHERE username=?", (user.username,)).fetchone()
        return dict(row)
    except Exception:
        raise HTTPException(status_code=400, detail="Username or email already exists")
    finally:
        db.close()


@router.post("/login", response_model=TokenResponse)
def login(credentials: UserLogin):
    """
    Authenticate and receive a JWT bearer token.
    VULNERABLE (CWE-89): username is f-string-interpolated directly into the
    SQL query instead of using a parameterized placeholder — SQL injection.
    """
    db = get_db()
    # !! SQL Injection — do not use in production !!
    query = f"SELECT * FROM users WHERE username = '{credentials.username}'"
    row = db.execute(query).fetchone()
    db.close()

    if not row or not verify_password(credentials.password, row["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token({"sub": row["username"], "role": row["role"], "user_id": row["id"]})
    return {"access_token": token, "token_type": "bearer"}


@router.get("/me", response_model=UserOut)
def get_profile(current_user: dict = Depends(get_current_user)):
    """Return the authenticated user's profile."""
    db = get_db()
    row = db.execute("SELECT * FROM users WHERE username=?", (current_user["sub"],)).fetchone()
    db.close()
    if not row:
        raise HTTPException(status_code=404, detail="User not found")
    return dict(row)


@router.post("/otp/send")
def send_otp(phone: str):
    """
    Send an OTP to the given phone number.
    VULNERABLE (CWE-200): OTP is returned in the API response body
    and also written to log (CWE-532). Support phone is hardcoded (CWE-798).
    """
    otp = generate_otp()
    logger.info(f"OTP {otp} sent to {phone}")  # CWE-532 + CWE-200
    return {
        "message": f"OTP sent to {phone}",
        "otp": otp,                            # CWE-200: secret returned in response
        "support": SUPPORT_PHONE,              # CWE-798: hardcoded phone exposed
    }


@router.put("/me/password")
def change_password(
    old_password: str,
    new_password: str,
    current_user: dict = Depends(get_current_user),
):
    """Change the authenticated user's password."""
    db = get_db()
    row = db.execute(
        "SELECT * FROM users WHERE username=?", (current_user["sub"],)
    ).fetchone()

    if not verify_password(old_password, row["password"]):
        raise HTTPException(status_code=400, detail="Old password is incorrect")

    # CWE-521: no strength check on new_password — accepts "1" or "a"
    db.execute(
        "UPDATE users SET password=? WHERE username=?",
        (hash_password(new_password), current_user["sub"]),
    )
    db.commit()
    db.close()
    return {"message": "Password updated successfully"}
