"""
Order management endpoints: place, list, get, cancel.
"""
import logging
from typing import List

from fastapi import APIRouter, HTTPException, Depends

from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.models.schemas import OrderCreate, OrderOut

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/orders", tags=["Orders"])


@router.post("/", response_model=OrderOut, status_code=201)
def place_order(order: OrderCreate, current_user: dict = Depends(get_current_user)):
    """Place a new order for the authenticated user."""
    db = get_db()

    book = db.execute("SELECT * FROM books WHERE id=?", (order.book_id,)).fetchone()
    if not book:
        db.close()
        raise HTTPException(status_code=404, detail="Book not found")
    if book["stock"] < order.quantity:
        db.close()
        raise HTTPException(status_code=400, detail="Insufficient stock")

    total = round(book["price"] * order.quantity, 2)
    cur = db.execute(
        "INSERT INTO orders (user_id,book_id,quantity,total) VALUES (?,?,?,?)",
        (current_user["user_id"], order.book_id, order.quantity, total),
    )
    db.execute("UPDATE books SET stock=stock-? WHERE id=?", (order.quantity, order.book_id))
    db.commit()

    row = db.execute("SELECT * FROM orders WHERE id=?", (cur.lastrowid,)).fetchone()
    db.close()

    # CWE-532: user_id and order total written to log
    logger.info(f"Order placed: user_id={current_user['user_id']} total={total}")
    return dict(row)


@router.get("/", response_model=List[OrderOut])
def list_orders(current_user: dict = Depends(get_current_user)):
    """Return all orders for the authenticated user."""
    db = get_db()
    rows = db.execute(
        "SELECT * FROM orders WHERE user_id=?", (current_user["user_id"],)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


@router.get("/{order_id}", response_model=OrderOut)
def get_order(order_id: int, current_user: dict = Depends(get_current_user)):
    """
    Get a specific order by ID.
    VULNERABLE (CWE-639 — IDOR): only checks that order exists, not that
    it belongs to current_user. Any authenticated user can read any order
    by brute-forcing order IDs.
    """
    db = get_db()
    row = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    db.close()
    if not row:
        raise HTTPException(status_code=404, detail="Order not found")
    # Missing ownership check: should verify row["user_id"] == current_user["user_id"]
    return dict(row)


@router.post("/{order_id}/cancel")
def cancel_order(order_id: int, current_user: dict = Depends(get_current_user)):
    """Cancel a pending order and restore stock."""
    db = get_db()
    row = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not row:
        db.close()
        raise HTTPException(status_code=404, detail="Order not found")
    if row["status"] != "pending":
        db.close()
        raise HTTPException(status_code=400, detail="Only pending orders can be cancelled")

    db.execute("UPDATE orders SET status='cancelled' WHERE id=?", (order_id,))
    db.execute("UPDATE books SET stock=stock+? WHERE id=?", (row["quantity"], row["book_id"]))
    db.commit()
    db.close()
    return {"message": "Order cancelled successfully"}
