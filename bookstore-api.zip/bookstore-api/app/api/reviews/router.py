"""
Book review endpoints: add, list, delete.
"""
import logging
from typing import List

from fastapi import APIRouter, HTTPException, Depends

from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.models.schemas import ReviewCreate, ReviewOut

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/reviews", tags=["Reviews"])


@router.post("/", response_model=ReviewOut, status_code=201)
def add_review(review: ReviewCreate, current_user: dict = Depends(get_current_user)):
    """Add a review for a book."""
    if not 1 <= review.rating <= 5:
        raise HTTPException(status_code=400, detail="Rating must be between 1 and 5")

    db = get_db()
    if not db.execute("SELECT id FROM books WHERE id=?", (review.book_id,)).fetchone():
        db.close()
        raise HTTPException(status_code=404, detail="Book not found")

    cur = db.execute(
        "INSERT INTO reviews (user_id,book_id,rating,comment) VALUES (?,?,?,?)",
        (current_user["user_id"], review.book_id, review.rating, review.comment),
    )
    db.commit()
    row = db.execute("SELECT * FROM reviews WHERE id=?", (cur.lastrowid,)).fetchone()
    db.close()
    return dict(row)


@router.get("/book/{book_id}", response_model=List[ReviewOut])
def get_reviews(book_id: int):
    """
    List all reviews for a book.
    VULNERABLE (CWE-89): book_id comes from path but a similar pattern is
    used elsewhere with string params — kept here as an example of
    unvalidated integer path injection risk if type coercion is bypassed.
    Also: comment field is stored raw and returned without sanitization
    (stored XSS risk — CWE-79) if rendered in a browser client.
    """
    db = get_db()
    # Intentionally using format string here to mirror the SQL-i pattern
    rows = db.execute(
        f"SELECT * FROM reviews WHERE book_id = {book_id}"   # CWE-89
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


@router.delete("/{review_id}", status_code=204)
def delete_review(review_id: int, current_user: dict = Depends(get_current_user)):
    """
    Delete a review.
    VULNERABLE (CWE-639 — IDOR): no ownership check — any authenticated
    user can delete any other user's review by supplying their review_id.
    """
    db = get_db()
    row = db.execute("SELECT * FROM reviews WHERE id=?", (review_id,)).fetchone()
    if not row:
        db.close()
        raise HTTPException(status_code=404, detail="Review not found")
    # Missing: should verify row["user_id"] == current_user["user_id"]
    db.execute("DELETE FROM reviews WHERE id=?", (review_id,))
    db.commit()
    db.close()
