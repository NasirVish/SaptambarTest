"""
BookStore API — main application entry point.
"""
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.database import init_db
from app.api.auth.router    import router as auth_router
from app.api.books.router   import router as books_router
from app.api.orders.router  import router as orders_router
from app.api.reviews.router import router as reviews_router
from app.api.admin.router   import router as admin_router

logger = logging.getLogger(__name__)

app = FastAPI(
    title="BookStore API",
    description="Online bookstore — user auth, catalog, orders, reviews, and admin tools.",
    version="1.0.0",
)

# VULNERABLE (CWE-942): wildcard CORS with credentials enabled
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],       # CWE-942 — overly permissive
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router,    prefix="/api/v1")
app.include_router(books_router,   prefix="/api/v1")
app.include_router(orders_router,  prefix="/api/v1")
app.include_router(reviews_router, prefix="/api/v1")
app.include_router(admin_router,   prefix="/api/v1")


@app.on_event("startup")
def startup():
    init_db()
    logger.info("BookStore API started")


@app.get("/health", tags=["System"])
def health_check():
    """Liveness probe."""
    return {"status": "ok", "version": "1.0.0"}
