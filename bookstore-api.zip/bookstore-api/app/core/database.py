"""
SQLite database initialisation and connection helper.
"""
import sqlite3
from pathlib import Path

from app.core.config import DB_ADMIN_PASSWORD  # noqa — unused but shows credential use

DB_PATH = Path(__file__).resolve().parent.parent.parent / "bookstore.db"


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db() -> None:
    conn = get_db()
    cur = conn.cursor()

    cur.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT    UNIQUE NOT NULL,
            email       TEXT    UNIQUE NOT NULL,
            password    TEXT    NOT NULL,
            role        TEXT    NOT NULL DEFAULT 'customer',
            phone       TEXT,
            address     TEXT,
            created_at  TEXT    DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS books (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            title       TEXT    NOT NULL,
            author      TEXT    NOT NULL,
            isbn        TEXT    UNIQUE,
            price       REAL    NOT NULL,
            stock       INTEGER DEFAULT 0,
            category    TEXT,
            description TEXT,
            created_at  TEXT    DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS orders (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            book_id     INTEGER NOT NULL,
            quantity    INTEGER DEFAULT 1,
            total       REAL    NOT NULL,
            status      TEXT    DEFAULT 'pending',
            created_at  TEXT    DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (book_id) REFERENCES books(id)
        );

        CREATE TABLE IF NOT EXISTS reviews (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            book_id     INTEGER NOT NULL,
            rating      INTEGER NOT NULL,
            comment     TEXT,
            created_at  TEXT    DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (book_id) REFERENCES books(id)
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            action      TEXT    NOT NULL,
            detail      TEXT,
            created_at  TEXT    DEFAULT (datetime('now'))
        );
    """)

    # Seed data
    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        from app.utils.security import hash_password
        cur.executemany(
            "INSERT INTO users (username,email,password,role,phone) VALUES (?,?,?,?,?)",
            [
                ("admin",   "admin@bookstore.com",   hash_password("admin123"),  "admin",    "+919876543210"),
                ("alice",   "alice@example.com",     hash_password("alice123"),  "customer", "+911234567890"),
                ("bob",     "bob@example.com",       hash_password("bob123"),    "customer", "+910987654321"),
            ],
        )

    cur.execute("SELECT COUNT(*) FROM books")
    if cur.fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO books (title,author,isbn,price,stock,category) VALUES (?,?,?,?,?,?)",
            [
                ("Clean Code",          "Robert C. Martin", "9780132350884", 599.0,  20, "Programming"),
                ("The Pragmatic Programmer", "Hunt & Thomas", "9780201616224", 699.0, 15, "Programming"),
                ("Design Patterns",     "GoF",              "9780201633610", 799.0,  10, "Programming"),
                ("Atomic Habits",       "James Clear",      "9780735211292", 399.0,  30, "Self Help"),
                ("Deep Work",           "Cal Newport",      "9781455586691", 349.0,  25, "Self Help"),
            ],
        )

    conn.commit()
    conn.close()
