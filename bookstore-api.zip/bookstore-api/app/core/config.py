"""
Application configuration.
VULNERABLE: Hardcoded secrets (CWE-798) — all sensitive values are
baked into source. In production these must come from environment
variables or a secrets manager.
"""

# ── Hardcoded secrets ──────────────────────────────────────────────────────────
SECRET_KEY        = "super-secret-jwt-key-123"   # CWE-798 : weak hardcoded JWT secret
ALGORITHM         = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

# ── Hardcoded DB credential ────────────────────────────────────────────────────
DATABASE_URL      = "sqlite:///./bookstore.db"
DB_ADMIN_PASSWORD = "Admin@1234"               # CWE-798 : hardcoded DB password

# ── Hardcoded third-party keys ─────────────────────────────────────────────────
SMTP_PASSWORD     = "smtp_pass_plain_text"     # CWE-798 : email credential in code
PAYMENT_API_KEY   = "pk_live_51HZtest0000KEY"  # CWE-798 : payment key in source

# ── Weak admin default ─────────────────────────────────────────────────────────
ADMIN_USERNAME    = "admin"
ADMIN_PASSWORD    = "admin123"                 # CWE-521 : weak password
SUPPORT_PHONE     = "+919876543210"            # CWE-798 : static phone in source

# ── Feature flags ──────────────────────────────────────────────────────────────
DEBUG             = True                       # CWE-489 : debug left on
