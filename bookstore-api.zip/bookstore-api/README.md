# BookStore API

A realistic FastAPI e-commerce backend used to test Vidura's
API documentation generation and SAST vulnerability scanning.

> ⚠️ **Do not deploy publicly.** This project contains 34 intentional
> security vulnerabilities. See `VULNERABILITIES.md` for the full list.

## Project Structure

```
bookstore-api/
├── app/
│   ├── main.py                   # App entry, CORS, router registration
│   ├── core/
│   │   ├── config.py             # Hardcoded secrets (intentional)
│   │   ├── database.py           # SQLite setup + seed data
│   │   └── dependencies.py       # Auth guards
│   ├── api/
│   │   ├── auth/router.py        # Register, login, OTP, profile
│   │   ├── books/router.py       # Book catalog CRUD + search
│   │   ├── orders/router.py      # Place, list, cancel orders
│   │   ├── reviews/router.py     # Add and list reviews
│   │   └── admin/router.py       # Diagnostic tools (many vulns)
│   ├── models/schemas.py         # Pydantic schemas
│   └── utils/
│       ├── security.py           # Hashing, JWT, OTP
│       └── logger.py             # Logger setup
├── uploads/                      # Used by file download endpoint
├── logs/                         # App log output
├── requirements.txt
├── .env.example
├── run.py
├── VULNERABILITIES.md            # Ground-truth answer key
└── README.md
```

## Setup & Run

```bash
cd bookstore-api
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python run.py
```

API available at `http://localhost:8000`
Swagger UI at `http://localhost:8000/docs`

## Seeded Credentials

| Username | Password  | Role     |
|----------|-----------|----------|
| admin    | admin123  | admin    |
| alice    | alice123  | customer |
| bob      | bob123    | customer |

## Endpoints Summary

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/health` | None | Health check |
| POST | `/api/v1/auth/register` | None | Register new user |
| POST | `/api/v1/auth/login` | None | Login, returns JWT |
| GET | `/api/v1/auth/me` | Bearer | Get own profile |
| POST | `/api/v1/auth/otp/send` | None | Send OTP |
| PUT | `/api/v1/auth/me/password` | Bearer | Change password |
| GET | `/api/v1/books/` | None | List books (paginated) |
| GET | `/api/v1/books/search?q=` | None | Search books |
| GET | `/api/v1/books/{id}` | None | Get single book |
| POST | `/api/v1/books/` | Admin | Create book |
| PUT | `/api/v1/books/{id}` | Admin | Update book |
| DELETE | `/api/v1/books/{id}` | Admin | Delete book |
| POST | `/api/v1/orders/` | Bearer | Place order |
| GET | `/api/v1/orders/` | Bearer | List own orders |
| GET | `/api/v1/orders/{id}` | Bearer | Get order (IDOR) |
| POST | `/api/v1/orders/{id}/cancel` | Bearer | Cancel order |
| POST | `/api/v1/reviews/` | Bearer | Add review |
| GET | `/api/v1/reviews/book/{id}` | None | Get book reviews |
| DELETE | `/api/v1/reviews/{id}` | Bearer | Delete review (IDOR) |
| GET | `/api/v1/admin/users` | ⚠️ None | List all users + PII |
| GET | `/api/v1/admin/config` | ⚠️ None | Dump config + secrets |
| POST | `/api/v1/admin/ping` | ⚠️ None | Ping host (cmd inject) |
| POST | `/api/v1/admin/calculate` | ⚠️ None | Eval expression |
| GET | `/api/v1/admin/file/download` | ⚠️ None | Download file (traversal) |
| POST | `/api/v1/admin/session/restore` | ⚠️ None | Restore pickle session |
| GET | `/api/v1/admin/fetch` | ⚠️ None | Fetch remote URL (SSRF) |
| GET | `/api/v1/admin/logs` | ⚠️ None | Read log file |
| DELETE | `/api/v1/admin/users/{id}` | ⚠️ None | Delete any user |
